Supported file types are: .ogg, .mp3, .wav

"Starting" folder contains sound effects that play when time is Starting
"Stopping" folder contains sound effects that play when time is Stopping
"Stopped" folder contains sounds that play during Stopped time
