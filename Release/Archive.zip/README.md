# THE TIMESTOPPER  V 1.5.3
A mod to bring your jojo fantasies into ULTRAKILL!
-------
### You can do shit like this:
<img alt="image" src="https://github.com/user-attachments/assets/5b9815ae-71b1-4097-a979-cec437a16064" />

or like this:
<img alt="image" src="https://github.com/user-attachments/assets/0f867686-e448-4c43-a29b-eda7fc8af9e9" />
(Yes, the grayscale effect is also included, and customizable)




-----

<img width="792" height="965" alt="image" src="https://github.com/user-attachments/assets/c749a532-8b55-437b-9093-1f9dbf508adf" />

------

## Disclaimer!
This mod may have minor bugs and balancing issues here and there, since it was originally only made for funzies.
However, any worries for it might corrupt your save files are unnecessary, you can mess around to your heart's content! \\^ v ^/

****

### Abilities:
+ You can punch and grapple enemies in stopped time, they will fly away when you start it
+ You can still throw coins in stopped time, they will remain in air, crazy tricks are possible!
+ You can still parry in stopped time
+ You can add your own sound effects and select any of which you wish
+ "No Weapon Cooldown" cheat works with Timestopper too
+ Gold Arm is upgradable through terminals fr fr
+ Customizable animation speed, timestop speed, healability, shader effects, and more...
+ ~~someone is watching you~~

### To do:
+ HandPaint compatability
+ Custom layer to obtain the gold arm from, not an altar that cums it out
+ Make *Special Mode* actually do something
+ Make certain bosses able to move in stopped time, optional, maybe
+ ~~Touch grass~~
+ Add sound to arm pickup animation too
+ Add more easter eggs
+ Beat P-2 without cheating

### Downsides / Current Bugs:
- -~~The pillar cums out the yellow arm wtf!~~
- -Stuck infinitely after act ending cutscenes (?)
- -No special mode yet

### �How to work with controllers�
Unfortunately, ULTRAKILL's controller inputs are smoothed, which means they stop when time stops too. But there is a solution, altough it be somewhat tideous.

1. Right click ULTRAKILL in your steam library and select `Properties`
2. From there go to the `Controller` tab, and enable `Override for ULTRAKILL`.
3. Click `Controller Configurator` (clickable text in the same tab)
4. Select your controller and set right joystic as mouse movement, and bind any key you want to the keyboard key that uses the Timestopper.

## �What to do if the mod doesn't work / if you find a bug�
Go to the mod's github page [here](https://github.com/GalvinVoltag/The-Timestopper), and create an issue. I'd appreciate if you'd copy-paste the full log (text from the terminal that opens with the game) inside triple quotes (\``` like this ```), it helps me diagnose the problem more efficiently and correctly. *Also you might wanna follow the issue, I might just build a fix release so that you don't need to wait until the next update.*


[![Buymeacoffee](https://github.com/user-attachments/assets/866f5254-f5d5-403b-a7a2-7ab5238efcb6)](https://coff.ee/galvinvoltag)

<details>
  <summary>Guide for dummies</summary>
  
   ### to first get the gold arm, find this frickin' door in 7-1, and carry the blue skull to it:

<img alt="image" src="https://github.com/user-attachments/assets/853368b8-4288-48b1-b7e8-f74815431b18" />
  
  #### The timestop ability will start with 3 seconds by default, you can upgrade your arm through this button
![image](https://github.com/user-attachments/assets/11be4c3f-bed5-4e1f-ba0c-4611bbe30c12)


#### and then this menu over here:
<img alt="image" src="https://github.com/user-attachments/assets/0272a2a5-bf4f-411e-9c95-2a88b7a97437" />


Each upgrade increases the time by around one second, changes by the upgrade count though. There can be a maximum of 10 upgrades.
</details>
