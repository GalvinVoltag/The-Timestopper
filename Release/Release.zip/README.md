# THE TIMESTOPPER
A mod to bring your jojo fantasies into ULTRAKILL!
-------
### You can do shit like this:
![image](https://github.com/user-attachments/assets/912e29b0-0aaa-4d5c-9c75-2fb54d20edb7)


or like this:
![image](https://github.com/user-attachments/assets/36ec4e68-94fc-4c1c-8a82-60b53ae3a94c)
(Yes, the grayscale effect is also included, and customizable)




-----
------

## Disclaimer!
This mod is not recommended for serious playthroughs, it is mainly meant for funzies. It is not fully done and bugs may occur. I recommend you to back up your save files if there is anything important there for you, just in case I mean.
It is also very OP, balancing timestop without keeping it as cool as it is, is very hard

****

### Abilities:
+ +You can punch enemies in stopped time, they will fly away when you start it
+ +You can still throw coins in stopped time, they will remain in air after a while, crazy tricks are possible
+ +You can still parry in stopped time
+ +No Weapon Cooldown cheat works with gold arm
+ +Gold Arm is upgradable through terminals fr
+ +The Freezeframe is able to move it's rockets in stopped time with the alt-fire
+ +Customizable animation speed, timestop speed, healability, shader effects, maximum upgrades, and more...

### To do:
+ Custom boss to obtain the gold arm from, not a statue that cums it out
+ Make *Special Mode* actually work
+ Make certain bosses able to move in stopped time, optional, maybe
+ More balancing work, overclocking mechanism, more visual trickery, etc.
+ ~Touch grass~
+ Make the gold arm appear in main menu V1 cool ascii art thingy
+ Add sound to arm pickup animation too
+ Add the warning a sound
+ Add more easter eggs
+ Beat P-2 without cheating
+ ~Make more friends~

### Downsides / Current Bugs:
- -Movement is a little bit janky in stopped time.
- -~The pillar cums out the yellow arm wtf!~
- -Stuck infinitely after act ending cutscenes, haven't checked if it's still there? (needs testing)
- -No special mode yet
- -No "ZA WARUDO" voiceline yet, only the sound effect





<details>
  <summary>Guide for dummies</summary>
  
   ### to first get the gold arm, find this frickin' door in 7-1:

  ![image](https://github.com/user-attachments/assets/ef4f57b3-d8e1-4428-886d-2b1fc1da7c17)

  
  #### The timestop ability will start with 3 seconds by default, you can upgrade your arm through this button
![image](https://github.com/user-attachments/assets/11be4c3f-bed5-4e1f-ba0c-4611bbe30c12)


#### and then this menu over here:
![image](https://github.com/user-attachments/assets/db0f0ee2-3562-449f-bebb-7840e6e571d6)


Each upgrade increases the time by around one second, changes by the upgrade count though. There can be a maximum of 10 upgrades.
</details>
